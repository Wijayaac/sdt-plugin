<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://https://wijayaac.netlify.app/
 * @since      1.0.0
 *
 * @package    Surya_Dt
 * @subpackage Surya_Dt/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
